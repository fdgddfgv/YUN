#!/bin/bash
# 定义目标路径
Zygote133="/storage/emulated/0/Zygote133/"
ksu="http://github.moeyy.xyz/https://raw.githubusercontent.com/Zygote133/Ycminuseee/refs/heads/main/ksunYC.zip"
arf="http://github.moeyy.xyz/https://raw.githubusercontent.com/Zygote133/Ycminuseee/refs/heads/main/%CE%B1YC.zip"
apd="http://github.moeyy.xyz/https://raw.githubusercontent.com/Zygote133/Ycminuseee/refs/heads/main/Apd.zip"
sh="/storage/emulated/0/Zygote133/helloworld"
mkdir -p "$Zygote133"
# 日志函数
log() {
    echo "[INFO] $1"
}

# 错误函数
error() {
    echo "[ERROR] $1" >&2
}

# 警告函数
warn() {
    echo "[WARN] $1"
}

# 下载文件函数
download_file() {
    local url=$1
    local output=$2
    
    log "开始下载:"
    
    if command -v wget >/dev/null 2>&1; then
        if ! wget -q --show-progress -O "$output" "$url"; then
            error "下载失败"
            return 1
        fi
    elif command -v curl >/dev/null 2>&1; then
        if ! curl -L --progress-bar -o "$output" "$url"; then
            error "下载失败"
            return 1
        fi
    else
        error "未找到wget或curl，无法下载文件"
        return 1
    fi
    
    # 检查文件完整性
    if [ ! -s "$output" ]; then
        error "下载的文件为空: $output"
        rm -f "$output"
        return 1
    fi
    
    log "下载成功"
    log "文件大小: $(du -h "$output" | cut -f1)"
}
if [ -d "/data/adb/ksu" ]; then
    log "检测到 /data/adb/ksu 文件夹，开始下载 ksu.zip"
    output_file="$Zygote133/ksu.zip"
    echo "找到ksu文件…"
    sleep 0.6
    if download_file "$ksu" "$output_file"; then
        sleep 0.6
        unzip -o "$output_file" -d "$Zygote133"
        clear
        sleep 0.6
        rm -rf "$output_file"
    fi
fi

if [ -d "/data/adb/ap" ]; then
    log "检测到 /data/adb/ap 文件夹，开始下载 apd.zip"
    output_file1="$Zygote133/apd.zip"
    if download_file "$apd" "$output_file1"; then
        sleep 0.6
        unzip -o "$output_file1" -d "$Zygote133"
        clear
        sleep 0.6
        rm -rf "$output_file1"
    fi
elif [ -d "/data/adb/magisk" ]; then
    log "未检测到 /data/adb/ksu 文件夹，开始下载 arf.zip"
    output_file2="$Zygote133/arf.zip"
    if download_file "$arf" "$output_file2"; then
        sleep 0.6
        unzip -o "$output_file2" -d "$Zygote133"
        clear
        sleep 0.6
        rm -rf "$output_file2"
    fi
fi
sleep 0.6
echo "下载完毕，执行脚本…"
sleep 0.3
rm -rf "$0"
sh "$sh"